{% macro get_big_table_name() %}

  `owox-test2.GA.big_table`

{% endmacro %}