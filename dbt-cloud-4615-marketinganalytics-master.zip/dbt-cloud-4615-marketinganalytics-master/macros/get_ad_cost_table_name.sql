{% macro get_ad_cost_table_name() %}

  `owox-test2.GA.utm_ad_cost`

{% endmacro %}